#==================================================
#  project:       Calcular los indicadores de pobreza monetaria y desigualdad

#  Dependencies: Dirección de Analisis de Pobreza, Desigualdad Y cultura Democratica- MEPyD
----------------------------------------------------
  #  Creation Date:    28 Feb 2023 - 11:02:22
  #Modification Date:   
  
  #Fuentes: 
  #  - Encuesta Nacional Continua de Fuerza de Trabajo, levantada por el Banco Central de la República Dominicana.
  #  - Indice de Precios al Consumidor (IPC) Base Diciembre 2010, publicado por el Banco Central de la República Dominicana. 
  # https://www.bancentral.gov.do/a/d/2534-precios
  # Archivo: Indice de precios al consumidor (IPC), 1984-2020
  #  - Tasa de cambio principales monedas.
  # https://www.bancentral.gov.do/a/d/2538-mercado-cambiario
  # Archivo: Otras monedas convertibles, serie histórica 2004-2020, mensual.

#Para el año 2020 en ingresos por transferencias se incluyen los ingresos de los programas de mitigación de la pandemia del COVID-19 Quédate En Casa, FASE I y II y PA TI'.

#Se recomienda al usuario crear un "Proyecto" en RStudio, en la misma carpeta donde haya guardado todos los 
#archivos necesarios. De esta forma R sabrá en qué carpeta buscar los archivos de forma automática.

#Se cargan las librerias

tryCatch(
  library(readxl),
  error = function(err){
    install.packages("readxl")
    library(readxl)
  }
)

tryCatch(
  library(tidyverse),
  error = function(err){
    install.packages("tidyverse")
    library(tidyverse)
  }
)

tryCatch(
  library(readr),
  error = function(err){
    install.packages("readr")
    library(readr)
  }
)

tryCatch(
  library(ineq),
  error = function(err){
    install.packages("ineq")
    library(ineq)
  }
)



tryCatch(
  library(Hmisc),
  error = function(err){
    install.packages("Hmisc")
    library(Hmisc)
  }
)

# Se establece directorio de trabajo 

setwd("C:/Users/cornelio.polanco/OneDrive - Ministerio de Economía, Planificación y Desarrollo/MEPyD/Codigos para publicar/Estimacion de pobreza en R")

# Cargar la base de datos ENCFT


encft <- read_delim("ENCFT 2016-2022.csv", 
                    delim = ";", escape_double = FALSE, trim_ws = TRUE, col_types = cols(ANO = col_double(), MES = col_double(), 
  HORAS_TRABAJO_EFECT_TOTAL = col_double(), TIEMPO_RECIBE_PAGO_AP = col_double(), INGRESO_ACTIVIDAD_IN_MONTO = col_double(),
  TIEMPO_RECIBE_PAGO_DIAS_AP = col_double(), VIVIENDA_ESPECIE_AP_MONTO = col_double(), INGRESO_ACTIVIDAD_IN_MONEDA = col_character(),
  OTROS_ESPECIE_AP_MONTO = col_double(), GANANCIA_IN_PRODUCTOR_MONTO = col_double(), 
  GANANCIA_IN_PRODUCTOR = col_double(), GANANCIA_PRINC_IMP_MONTO = col_double(), 
  GANANCIA_IN_PRODUCTOR_MONEDA = col_character(), PAGO_ESPECIES_IN_MONTO = col_double(), SUELDO_BRUTO_AP_MONTO = col_double(),
  SALARIO_SECUN_IMP_MONTO = col_double(), GANANCIA_SECUN_IMP_MONTO = col_double(), 
  GANANCIA_IS_PRODUCTOR = col_double(), GANANCIA_IS_PRODUCTOR_MONTO = col_double(),
  GANANCIA_IS_PRODUCTOR_MONEDA = col_character(), INGRESO_ACTIVIDAD_IS_MONEDA = col_character(),  SUELDO_BRUTO_AP_MONEDA = col_character(),
   INGRESO_ACTIVIDAD_IS_MONTO = col_double(), PAGO_ESPECIES_IS_MONTO = col_double(), PENSION_IMP_MONTO = col_double(),
    INTERESES_NAC_ANO_MONTO = col_double(), ALQUILER_NAC_ANO_MONTO = col_double(), REMESAS_NAC_ANO = col_double(), 
    REMESAS_NAC_ANO_MONTO = col_double(), CONSUMO_CULTIVO_MONTO = col_double(), PESCA_NO_REMUN_MONTO = col_double(), PENSION_EXT_MONTO = col_double(),
     ALIMENTOS_NO_REMUN_MONTO = col_double(), CULTIVO_NO_REMUN_PORC = col_double(), PESCA_NO_REMUN_PORC = col_double(), PENSION_EXT_MONEDA = col_character(),
     ALIMENTOS_NO_REMUN_PORC = col_double(), INTERES_EXT_MONEDA = col_character(), ALQUILER_EXT_MONEDA = col_character(), REMESAS_EXT = col_double(),
    INTERES_EXT_MONTO = col_double(), ALQUILER_EXT_MONTO = col_double(), GOB_QUEDATE_EN_CASA = col_double(), SUPERATE = col_double(), 
    GOB_FONDO_ASISTENCIA_FASE = col_double(), GOB_PROGRAMA_PATI = col_double(), PENSION_NAC = col_double(), PENSION_NAC_MONTO = col_double(), 
  MES1_1_EXT_MONTO = col_double(), MES2_1_EXT_MONTO = col_double(),MES3_1_EXT_MONTO = col_double(),MES4_1_EXT_MONTO = col_double(),
  MES5_1_EXT_MONTO = col_double(),MES6_1_EXT_MONTO = col_double(), INGRESO_ACTIVIDAD_IS_MONEDA = col_character(), INGRESO_ACTIVIDAD_IS_MONTO = col_double(),
  MES1_2_EXT_MONTO = col_double(), MES2_2_EXT_MONTO = col_double(),MES3_2_EXT_MONTO = col_double(),MES4_2_EXT_MONTO = col_double(),
  MES5_2_EXT_MONTO = col_double(),MES6_2_EXT_MONTO = col_double(),
  MES1_3_EXT_MONTO = col_double(), MES2_3_EXT_MONTO = col_double(),MES3_3_EXT_MONTO = col_double(),MES4_3_EXT_MONTO = col_double(),
  MES5_3_EXT_MONTO = col_double(),MES6_3_EXT_MONTO = col_double(),
  MES1_1_EXT_MONEDA = col_character(), MES2_1_EXT_MONEDA = col_character(),MES3_1_EXT_MONEDA = col_character(),MES4_1_EXT_MONEDA = col_character(),
  MES5_1_EXT_MONEDA = col_character(),MES6_1_EXT_MONEDA = col_character(),
  MES1_2_EXT_MONEDA = col_character(), MES2_2_EXT_MONEDA = col_character(),MES3_2_EXT_MONEDA = col_character(),MES4_2_EXT_MONEDA = col_character(),
  MES5_2_EXT_MONEDA = col_character(),MES6_2_EXT_MONEDA = col_character(),
  MES1_3_EXT_MONEDA = col_character(), MES2_3_EXT_MONEDA = col_character(),MES3_3_EXT_MONEDA = col_character(),MES4_3_EXT_MONEDA = col_character(),
  MES5_3_EXT_MONEDA = col_character(),MES6_3_EXT_MONEDA = col_character()
                    ))

# convierten los nombres en minúscula 

names(encft) <-  tolower(names(encft))

gc()
memory.size (max = F)

# Asigno más memoria
memory.limit(size=20000)

# Crear variable auxiliar personas
encft$personas <- 1

# Asignar etiqueta a variable personas
label(encft$personas) <- "variable auxiliar persona"

# Generar la variable miembros
encft <- encft %>% 
  group_by(trimestre, vivienda, hogar) %>% 
  mutate(miembros = sum(personas)) %>% 
  ungroup() %>% 
  arrange(periodo, vivienda, hogar, miembros)


# se carga el excel con los tipos de cambio otras monedas convertibles

TDC <- read_excel("TASAS_CONVERTIBLES_OTRAS_MONEDAS.xlsx", sheet = "Mensual",col_names = T, skip = 2)

names(TDC) <- tolower(names(TDC))

TDC <- TDC %>%  mutate(mes = case_when(mes =="Aug" ~ "Ago",
                                       TRUE ~ mes))

meses <- c("Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic")

TDC$mes[TDC$mes %in% meses] <- sprintf("%02d", match(TDC$mes[TDC$mes %in% meses], meses))

TDC$periodo <- paste(TDC$año, TDC$mes, sep = "")
TDC$periodo <- as.integer(TDC$periodo)
TDC <- TDC %>%
  filter(!is.na(periodo)) %>%
  mutate(dop = 1,
         pais16 = 0,
         pais16 = case_when(
           periodo == "201611" ~ 3.07,
           periodo == "201612" ~ 2.92,
           periodo == "201701" ~ 2.94,
           periodo == "201702" ~ 3.01,
           periodo == "201703" ~ 3.03,
           periodo == "201704" ~ 3.04,
           TRUE ~ pais16
         )) %>%
  rename(pais1 = dop, pais2 = euro, pais3 = "dolar estadounidense", pais4 = "real brasileno", pais5 = "dolar canadiense", 
         pais6 = "franco suizo", pais7 = "yuan chino", pais8 = "derecho especial de giro", pais9 = "corona danesa",
         pais10 = "libra esterlina", pais11 = "libra escocesa", pais12 = "yen japones", pais13 = "corona noruega", pais14 = "corona sueca", 
         pais15 = "bolivar fuerte venezolano") 

##### Se construye una variable de trimestre 

TDC <-  TDC %>% 
  mutate(mes = as.numeric(as.character(mes)),
    trimestre = case_when(mes <= 3 ~ 1, 
                               mes >= 4 & mes <= 6 ~ 2,
                               mes >= 7 & mes <= 9 ~ 3,
                               mes >= 10  ~ 4,
                          TRUE ~ NA_real_))

## Se reestructuran los datos

TDC <- pivot_longer(TDC, cols = paste0("pais", 1:16), names_to = "pais17", values_to = "tasa", names_prefix = "pais", values_drop_na = TRUE)

TDC <- select(TDC, año, mes, periodo, trimestre, pais17, tasa)


# Renombra las columnas
colnames(TDC) <- c("ano", "mes", "periodo", "trimestre", "moneda", "tasa")

# Convierte la columna pais a un tipo de datos numérico
TDC$moneda <- as.numeric(as.character(TDC$moneda))

# Asigna etiquetas a los valores de pais

pais_labels <- c("DOP", "EUR", "USD", "REAL", "CAD", "CHF", "CNY", "DEG", "DKK", "GBP", "LESC", "JPY",  "NOK", "SEK", "VEF", "ARS")
TDC$moneda <- factor(TDC$moneda, levels = 1:16, labels = pais_labels)



TDC <- TDC %>%
  mutate(tasa_a_pesos_mes6 = lag(tasa, 16),
         tasa_a_pesos_mes5 = lag(tasa_a_pesos_mes6, 16),
         tasa_a_pesos_mes4 = lag(tasa_a_pesos_mes5, 16),
         tasa_a_pesos_mes3 = lag(tasa_a_pesos_mes4, 16),
         tasa_a_pesos_mes2 = lag(tasa_a_pesos_mes3, 16),
         tasa_a_pesos_mes1 = lag(tasa_a_pesos_mes2, 16))

TDC <- TDC %>%  select(periodo, trimestre, ano, moneda, mes, c(paste0("tasa_a_pesos_mes", 1:6) ))


TDC <-  TDC %>% 
  mutate(tasa_a_pesos_promedio = rowMeans(select(.,tasa_a_pesos_mes1, tasa_a_pesos_mes2, tasa_a_pesos_mes3,
                                          tasa_a_pesos_mes4, tasa_a_pesos_mes5, tasa_a_pesos_mes6), na.rm=T))


# Crear un vector con los nombres de las variables
variables <- c("sueldo_bruto_ap", "ingreso_actividad_in", "ingreso_actividad_is", "regalos_ext", "otros_ingresos_ext", "alquiler_ext", "interes_ext", "pension_ext")

# Iterar sobre el vector y crear las variables con el sufijo "_moneda" igual a las monedas que llegan al pais 
for (var in variables) {
  TDC <- TDC %>% mutate(!!paste0(var, "_moneda") := moneda)
}


# Iterar sobre el vector y crear las variables con el sufijo "_tasa" 
#igual al valor de cambio segun el BCRD

for (var in variables) {
  TDC <- TDC %>% mutate(!!paste0(var, "_tasa") := tasa_a_pesos_mes6)
  
}




# Se crea la variable moneda de los tres meses que comprende un trimestre
for (i in 1:6) {
  TDC <- TDC %>% mutate(!!paste0("mes", i, "_1_ext_moneda") := moneda)
}

for (i in 1:6) {
  TDC <- TDC %>% mutate(!!paste0("mes", i, "_2_ext_moneda") := moneda)
}


for (i in 1:6) {
  TDC <- TDC %>% mutate(!!paste0("mes", i, "_3_ext_moneda") := moneda)
}



# Se crea la variable tasa de los tres meses que comprende un trimestre
for (i in 1:6) {
  var_name <- paste0("mes", i, "_1_ext_tasa")
  TDC <- TDC %>% mutate({{var_name}} := get(paste0("tasa_a_pesos_mes", i)))
}

for (i in 1:6) {
  var_name <- paste0("mes", i, "_2_ext_tasa")
  TDC <- TDC %>% mutate({{var_name}} := get(paste0("tasa_a_pesos_mes", i)))
}


for (i in 1:6) {
  var_name <- paste0("mes", i, "_3_ext_tasa")
  TDC <- TDC %>% mutate({{var_name}} := get(paste0("tasa_a_pesos_mes", i)))
}


# se re-codifica la variable moneda de envio en la ENCFT


# Definimos el vector de países y sus códigos

codigos <- 1:16

# Loop for para aplicar las sustituciones y convertir a número






variables <-  c("sueldo_bruto_ap_moneda","ingreso_actividad_in_moneda","ingreso_actividad_is_moneda",
                "regalos_ext_moneda","otros_ingresos_ext_moneda","alquiler_ext_moneda", "interes_ext_moneda",
                "pension_ext_moneda")

# Definir vector de nombres de variables
variables <- c("sueldo_bruto_ap_moneda", "ingreso_actividad_in_moneda", "ingreso_actividad_is_moneda", "regalos_ext_moneda", "otros_ingresos_ext_moneda", "alquiler_ext_moneda", "interes_ext_moneda", "pension_ext_moneda")

# Seleccionar variables usando all_of()
encft <- encft %>% 
  mutate(across(all_of(variables), ~ ifelse(.x == "DOP", "1", 
                    ifelse(.x == "EUR", "2", 
                    ifelse(.x == "USD", "3", 
                     ifelse(.x == "REAL", "4", 
                     ifelse(.x == "CAD", "5", 
                    ifelse(.x == "CHF", "6",
                   ifelse(.x == "CNY", "7",
                   ifelse(.x == "DEG", "8",
                  ifelse(.x == "DKK", "9",
                 ifelse(.x == "GBP", "10",
                 ifelse(.x == "LESC", "11",        
                ifelse(.x == "JPY", "12",
              ifelse(.x == "NOK", "13",
            ifelse(.x == "SEK", "14",
          ifelse(.x == "VEF", "15",
    ifelse(.x == "ARS", "16", .x)))))))))))))))))) %>% 
  mutate(across(all_of(variables), ~factor(., levels = c(1, 2, 3, 4, 5, 6, 7, 8,
                                                     9, 10, 11, 12, 13, 14, 15,16), 
        labels = c("DOP","EUR", "USD", "REAL", "CAD", "CHF", "CNY", "DEG", "DKK", 
                   "GBP","LESC", "JPY", "NOK", "SEK", "VEF", "ARS"))))
           


for (x in c("sueldo_bruto_ap", "ingreso_actividad_in", "ingreso_actividad_is", "regalos_ext", "otros_ingresos_ext", "alquiler_ext", "interes_ext", "pension_ext")) {
  encft <- left_join(encft, TDC %>% select(periodo, paste0(x, "_moneda"), paste0(x, "_tasa")), 
                        by = c("periodo", paste0(x, "_moneda"))) %>% 
    filter(!is.na(paste0(x, "_tasa")))
}



### Traemos las variables de remesas

variables <- c("mes1_1_ext_moneda","mes2_1_ext_moneda","mes3_1_ext_moneda",
               "mes4_1_ext_moneda", "mes5_1_ext_moneda","mes6_1_ext_moneda",
               "mes1_2_ext_moneda","mes2_2_ext_moneda","mes3_2_ext_moneda",
               "mes4_2_ext_moneda", "mes5_2_ext_moneda","mes6_2_ext_moneda",
               "mes1_3_ext_moneda","mes2_3_ext_moneda", "mes3_3_ext_moneda",
               "mes4_3_ext_moneda","mes5_3_ext_moneda","mes6_3_ext_moneda")

# Seleccionar variables usando all_of()
encft <- encft %>% 
  mutate(across(all_of(variables), ~ ifelse(.x == "DOP", "1", 
                                    ifelse(.x == "EUR", "2", 
                                   ifelse(.x == "USD", "3", 
                                  ifelse(.x == "REAL", "4", 
                                  ifelse(.x == "CAD", "5", 
                                  ifelse(.x == "CHF", "6",
                                  ifelse(.x == "CNY", "7",
                                  ifelse(.x == "DEG", "8",
                                  ifelse(.x == "DKK", "9",
                                  ifelse(.x == "GBP", "10",
                                  ifelse(.x == "LESC", "11",        
                                  ifelse(.x == "JPY", "12",
                                  ifelse(.x == "NOK", "13",
                                 ifelse(.x == "SEK", "14",
                                 ifelse(.x == "VEF", "15",
                                ifelse(.x == "ARS", "16", .x)))))))))))))))))) %>% 
  mutate(across(all_of(variables), ~factor(., levels = c(1, 2, 3, 4, 5, 6, 7, 8,
                                                   9, 10, 11, 12, 13, 14, 15,16), 
labels = c("DOP","EUR", "USD", "REAL", "CAD", "CHF", "CNY", "DEG", "DKK", 
                     "GBP","LESC", "JPY", "NOK", "SEK", "VEF", "ARS"))))



#variable de remesas que van del 1 al 6, mes 1

for (i in 1:6){ 

encft <- left_join(encft, TDC %>% select(periodo, paste0("mes",i,"_1_ext_moneda"), paste0("mes",i,"_1_ext_tasa")),
                                           by=c("periodo",paste0("mes",i,"_1_ext_moneda"))) %>% 
                                          filter(!is.na(paste0("mes",i,"_1_ext_tasa")))
}


#variable de remesas que van del 1 al 6, mes 2

for (i in 1:6){ 
  
  encft <- left_join(encft, TDC %>% select(periodo, paste0("mes",i,"_2_ext_moneda"), paste0("mes",i,"_2_ext_tasa")),
                     by=c("periodo",paste0("mes",i,"_2_ext_moneda"))) %>% 
    filter(!is.na(paste0("mes",i,"_2_ext_tasa")))
}
   

#variable de remesas que van del 1 al 6, mes 3

for (i in 1:6){ 
  
  encft <- left_join(encft, TDC %>% select(periodo, paste0("mes",i,"_3_ext_moneda"), paste0("mes",i,"_3_ext_tasa")),
                     by=c("periodo",paste0("mes",i,"_3_ext_moneda"))) %>% 
    filter(!is.na(paste0("mes",i,"_3_ext_tasa")))
}

                                     
#/*==================================================
#  2: Se trabajan los ingresos laborales 
#==================================================*/
  
  #*----------2.1 Ingreso por trabajo asalariado principal: salario :
  #  B.4.2. ¿Cuánto fue el salario o sueldo sin ningún tipo de descuento que recibió ...
  #en su empleo principal?(Sólo considere el salario sin descuentos, no incluya comisiones
  #                      , propinas, etc.)*/
  
# Ingreso por trabajo asalariado principal  p_s4b42 

    encft <- encft %>% 
      mutate(p_s4b42 = case_when(tiempo_recibe_pago_ap == 4 ~ sueldo_bruto_ap_monto*sueldo_bruto_ap_tasa,
                                 tiempo_recibe_pago_ap==3 ~ sueldo_bruto_ap_monto*sueldo_bruto_ap_tasa*2,
                                 tiempo_recibe_pago_ap==2 ~ sueldo_bruto_ap_monto*sueldo_bruto_ap_tasa*4.3,
                                 tiempo_recibe_pago_ap==1 ~ sueldo_bruto_ap_monto*tiempo_recibe_pago_dias_ap*sueldo_bruto_ap_tasa*4.3,
                                 TRUE ~ NA_real_
                                 ))

# Calcular el promedio de p_s4b42 para aquellos ocupados mayores de 14 años
encft %>% group_by(ano) %>%filter(ocupado==1 & edad>14) %>% summarise(mean(p_s4b42, na.rm = T))

# Crear la variable salario_princ_imp_monto1 basada en sueldo_princ_imp_monto
encft$salario_princ_imp_monto1 <- if_else(encft$sueldo_bruto_ap == 2, encft$salario_princ_imp_monto, NA_real_)
# Calcular la suma de salario_princ_imp_monto1 y p_s4b42 agrupados por periodo
encft$p_s4b42_1 <- rowSums(select(encft, salario_princ_imp_monto1, p_s4b42), na.rm = TRUE)

# Establecer etiquetas a las variables
label(encft$p_s4b42) <- "Ingreso por sueldo y salario, ocupación principal"
label(encft$p_s4b42_1) <- "Ingreso por sueldo y salario y sueldo y salario imputado, ocupación principal"
label(encft$salario_princ_imp_monto) <- "Ingreso por sueldo y salario imputado, ocupación principal"


#----------2.2 Otros ingresos laborales monetarios:
  

#  B.4.3. Durante el mes pasado, … recibió en su empleo principal1.
#a- Mes pasado: 
#  1. Comisiones.														comisiones_ap_monto
#2. Propinas 															propinas_ap_monto
#3. Pago por horas extras												horas_extra_ap_monto
#99.Otros pagos (Pasajes, viático, dieta, etc) (especifique)			otros_pagos_ap_monto
#B.4.5. ¿Durante el mes pasado en su empleo principal … recibió
#b- Ultimos 12 meses:
#  1. Vacaciones bonificadas 					vacaciones_ap_monto
#2. Bonificación3. 							bonificacion_ap_monto
#3. Regalía pascual4. 							regalia_ap_monto
#4. Incentivo por antigüedad5. 				incentivo_antiguedad_ap_monto
#5. Dividendos6. 								dividendos_ap_monto
#6. Beneficios marginales7.					beneficios_marginales_ap_monto
#7. Utilidades empresariales99. 				utilidad_empresarial_ap_monto
#99. Otros pagos o beneficios (especifique)		otros_beneficios_ap_monto

encft <- encft %>% 
  mutate(p_s4b43_1 = ifelse(comisiones_ap == 1, comisiones_ap_monto, NA_real_),
         p_s4b43_2 = ifelse(propinas_ap == 1, propinas_ap_monto, NA_real_),
         p_s4b43_3 = ifelse(horas_extra_ap == 1, horas_extra_ap_monto, NA_real_),
         p_s4b43_99 = ifelse(otros_pagos_ap == 1, otros_pagos_ap_monto, NA_real_),
         p_s4b44_1 = ifelse(vacaciones_ap == 1, vacaciones_ap_monto/12, NA_real_),
         p_s4b44_5 = ifelse(dividendos_ap == 1, dividendos_ap_monto/12, NA_real_),
         p_s4b44_2 = ifelse(bonificacion_ap == 1, bonificacion_ap_monto/12, NA_real_),
         p_s4b44_3 = ifelse(regalia_ap == 1, regalia_ap_monto/12, 
                            ifelse(regalia_ap == 2, regalia_princ_imp_monto/12, NA_real_)),
         p_s4b44_7 = ifelse(utilidad_empresarial_ap == 1, utilidad_empresarial_ap_monto/12, NA_real_),
         p_s4b44_6 = ifelse(beneficios_marginales_ap == 1, beneficios_marginales_ap_monto/12, NA_real_),
         p_s4b44_4 = ifelse(incentivo_antiguedad_ap == 1, incentivo_antiguedad_ap_monto/12, NA_real_),
         p_s4b44_99 = ifelse(otros_beneficios_ap == 1, otros_beneficios_ap_monto/12, NA_real_))

# Establecer etiquetas a las variables
label(encft$p_s4b43_1) <- "Comisiones, ocupación principal"
label(encft$p_s4b43_2) <- "Propinas, ocupación principal"
label(encft$p_s4b43_3) <- "Horas extras, ocupación principal"
label(encft$p_s4b43_99) <- "Otros ingresos extras, ocupación principal"
label(encft$p_s4b44_1) <- "Vacaciones pagadas, ocupación principal"
label(encft$p_s4b44_5) <- "Dividendos, ocupación principal"
label(encft$p_s4b44_2) <- "Bonificación, ocupación principal"
label(encft$p_s4b44_3) <- "Regalía pascual, ocupación principal"
label(encft$p_s4b44_7) <- "Utilidades empresariales, ocupación principal"
label(encft$p_s4b44_6) <- "Beneficios marginales, ocupación principal"
label(encft$p_s4b44_4) <- "Incentivos por antiguedad, ocupación principal"
label(encft$p_s4b44_99) <- "Otros ingresos monetarios laborales anuales, ocupación principal"


#*----------2.3 Ingreso laboral en especie ocupación principal :
#  B.4.5. ¿Durante el mes pasado en su empleo principal … recibió pagos en especie por
#1. Alimentación?  															alimentacion_especie_ap_monto
#2. Vivienda?																vivienda_especie_ap_monto
#3. Servicio de transporte?													transporte_especie_ap_monto										
#4. Asignación de combustible? 												gasolina_especie_ap_monto
#5. Celular?																	celular_especie_ap_monto
#99. Otros (especifique)?(Pase a sección B.6 pregunta B.6.1)					otros_especie_ap_monto

encft <- encft %>% 
  mutate(p_s4b45_1 = ifelse(!is.na(alimentacion_especie_ap_monto), alimentacion_especie_ap_monto, NA_real_),
         p_s4b45_2 = ifelse(!is.na(vivienda_especie_ap_monto), vivienda_especie_ap_monto, NA_real_),
         p_s4b45_3 = ifelse(!is.na(transporte_especie_ap_monto), transporte_especie_ap_monto, NA),
         p_s4b45_4 = ifelse(!is.na(gasolina_especie_ap_monto), gasolina_especie_ap_monto, NA_real_),
         p_s4b45_5 = ifelse(!is.na(celular_especie_ap_monto), celular_especie_ap_monto, NA_real_),
         p_s4b45_99 = ifelse(!is.na(otros_especie_ap_monto), otros_especie_ap_monto, NA_real_))

# Agregar etiquetas a las variables creadas
label(encft$p_s4b45_1) <- "Pago en especie-Alimentos, ocupación principal"
label(encft$p_s4b45_2) <- "Pago en especie-Vivienda, ocupación principal"
label(encft$p_s4b45_3) <- "Pago en especie-Transporte, ocupación principal"
label(encft$p_s4b45_4) <- "Pago en especie-Gasolina, ocupación principal"
label(encft$p_s4b45_5) <- "Pago en especie-Celular, ocupación principal"
label(encft$p_s4b45_99) <- "Pago en especie-Otros, ocupación principal"



#----------2.4 Ingreso por trabao aslariado sencundario, salario:
#  B.7.1. ¿Cuánto fue el salario, sueldo o jornal sin ningún tipo de descuento que recibió ... el mes pasado en su empleo secundario?

encft <- encft %>% 
  mutate(p_s4b71 = ifelse(sueldo_bruto_as==1, sueldo_bruto_as_monto, salario_secun_imp_monto))

#B.7.2. Durante el mes pasado, además del salario, sueldo o jornal,
#¿… recibió en su empleo secundario algún otro pago como comisiones, propinas, horas extras, otros pagos?

encft <- encft %>% 
  mutate(p_s4b72 = ifelse(otros_pago_as == 1,otros_pago_as_monto,NA_real_))

#B.7.3. Durante los últimos 12 meses, ¿en su empleo secundario ... recibió algún otro ingreso como vacaciones 
#bonificadas, bonificaciones, regalía pascual u otros pagos o beneficios?

encft <- encft %>% 
  mutate(p_s4b73 = ifelse(otros_beneficios_as == 1 , otros_beneficios_as_monto/12 ,NA_real_))

#B.7.4. Durante el mes pasado en su empleo secundario 
#¿... recibió algún pago en especie como alimento, vivienda, servicio de transporte, combustible, celular, etc.?

encft <- encft %>% 
  mutate(p_s4b74 = ifelse(pago_en_especie_as == 1  , pago_en_especie_as_monto,NA_real_))
# Agregar etiquetas a las variables creadas
label(encft$p_s4b71) <-  "Ingreso por sueldo y salario, ocupación secundaria"
label(encft$p_s4b72) <-  "Ingreso por comisiones,propinas, horas extras y otros ingresos extras. Ocupación secundaria"
label(encft$p_s4b73) <-  "Ingreso por vacaciones, bonificaciones, regalía pascual u otros pagos o beneficios. Ocupacipación secundaria"
label(encft$p_s4b74) <-  "Pagos en especie(Alimentos,vivienda,transporte,etc. Ocupación secundaria"

#==================================================
#  3: Ingreso laboral  y ganancias por cuenta propia
#==================================================*/
  
  
#  *----------3.1 Ingresos monetario actividad principal: trabajador por cuenta propia:
#  /*B.5.3. ¿A cuánto ascendieron sus ingresos o ganancias netas de su actividad, negocio, profesión u oficio durante el mes pasado?
 
# Crear variable ingprinctaprop

# Se mensualiza el Ingresos monetario actividad principal: trabajador por cuenta propia
encft <- encft %>% 
  mutate(p_s4b53_1 = case_when(ingreso_actividad_in_periodo == 4 ~ ingreso_actividad_in_monto*ingreso_actividad_in_tasa,
                               ingreso_actividad_in_periodo == 3 ~ ingreso_actividad_in_monto*ingreso_actividad_in_tasa*2,
                               ingreso_actividad_in_periodo == 2 ~ingreso_actividad_in_monto*ingreso_actividad_in_tasa*4.3,
                               ingreso_actividad_in_periodo == 1 ~ ingreso_actividad_in_monto*ingreso_actividad_in_dias*ingreso_actividad_in_tasa*4.3,
                               TRUE ~ NA_real_))
encft %>% group_by(ano) %>%filter(ocupado==1 & edad>14) %>% summarise(mean(p_s4b53_1, na.rm = T))



# Existen ingresos imputados de esta partida 
encft <- encft %>% 
  mutate(ganancia_princ_imp_monto1 = ifelse(ingreso_actividad_in == 2,ganancia_princ_imp_monto, 0))

#----------3.2 Ganancias del productor y cuenta propia:
encft <- encft %>% 
  mutate(p_s4b52 = ifelse( ganancia_in_productor == 1 ,ganancia_in_productor_monto/6 , 0 ),
         ganancia_princ_imp_monto2 = ifelse( ganancia_in_productor == 2, ganancia_princ_imp_monto,0))

# "Ganancia neta de empleador, consultor, cuenta propia y patron, ocupación principal trabajador independiente
encft$p_s4b5_2a3 <- rowSums(select(encft, p_s4b52, p_s4b53_1, ganancia_princ_imp_monto1, ganancia_princ_imp_monto2), na.rm = T)
# SE verifica los resultados promedios
encft %>% group_by(ano) %>%filter(ocupado==1 & edad>14) %>% summarise(mean(p_s4b5_2a3 , na.rm = T))


#----------3.3 ingresos laborales ocupación principal: independientes especie y Autoconsumo:
  
  
# B.5.5. Durante el mes pasado ¿Recibió por este trabajo algún pago en especie (alimentos, mercancía, etc)?

encft$p_s4b55 <-  ifelse(encft$pago_especies_in==1, encft$pago_especies_in_monto, NA_real_)
label(encft$p_s4b55) <- "Ingreso en especie, ocupación principal trabajador independiente"

# B.5.4. De lo que produce o vende su empresa o negocio, ¿utiliza alguna cantidad para consumo personal o de su hogar?

encft$p_s4b54 <-  ifelse(encft$consumio_bienes_in==1, encft$consumio_bienes_in_monto, NA_real_)
label(encft$p_s4b54) <- "Autoconsumo, ocupación principal trabajador independiente"

#----------3.4 ingresos laborales ocupación Secundaria : independientes monetarios:
# se crea variable con el ingreso por actividad secundaria en pesos

#Se mensualizan los montos de ingresos laborales ocupación Secundaria

encft <- encft %>% 
  mutate(p_s4b83 = case_when(ingreso_actividad_is_periodo == 4 ~ ingreso_actividad_is_monto*ingreso_actividad_is_tasa,
                             ingreso_actividad_is_periodo == 3 ~ ingreso_actividad_is_monto*ingreso_actividad_is_tasa*2,
                             ingreso_actividad_is_periodo == 2 ~ ingreso_actividad_is_monto*ingreso_actividad_is_tasa*4.3,
                             ingreso_actividad_is_periodo == 1 ~ ingreso_actividad_is_monto*ingreso_actividad_is_tasa *ingreso_actividad_is_dias*4.3,
                             TRUE ~ NA_real_))

encft$ganancia_secun_imp_monto1 <- ifelse(encft$ingreso_actividad_is == 2, encft$ganancia_secun_imp_monto,0)

encft %>% group_by(ano) %>%filter(ocupado==1 & edad>14) %>% summarise(mean(p_s4b83, na.rm = T))

#----------3.5 Ganancias  cuenta propia ocupación secundaria:

encft <-  encft %>% 
  mutate(p_s4b82 = ifelse(ganancia_is_productor == 1, ganancia_is_productor_monto/6, NA_real_),
         ganancia_secun_imp_monto2 = ifelse(ganancia_is_productor == 2, ganancia_secun_imp_monto, NA_real_),
         )

encft$p_4b8_2a3 = rowSums(select(encft,p_s4b83, p_s4b82, ganancia_secun_imp_monto1, ganancia_secun_imp_monto2), na.rm = T)

# Se agregan Etiquetas
label(encft$p_s4b83) <-  "Ganancia neta de productor y consultor, ocupación secundaria"
label(encft$p_s4b82) <-  "Ganancia neta de trabajador por cuenta propia y patron,ocupación secundaria"
label(encft$ganancia_secun_imp_monto) <-  "Ganancia neta imputada de trabajador por cuenta propia y patron"
label(encft$p_4b8_2a3) <-  "Ganancia neta de empleador, consultor, cuenta propia y patron, ocupación secundaria"

#----------3.6 Autoconsumo ocupación secundaria :

#B.8.4. De lo que produce o vende su empresa o negocio, ¿utiliza alguna cantidad para consumo personal o de su hogar?

encft$p_s4b84 <- ifelse(encft$consumio_bienes_is == 1,encft$consumio_bienes_is_monto, NA_real_)
label(encft$p_s4b84) <- "Auconsumo, ocupación secundario"

# B.8.5. Durante el mes pasado ¿Recibió por este trabajo algún pago en especie (alimentos, mercancía, etc)?
encft$p_s4b85 <- ifelse(encft$pago_especies_is == 1, encft$pago_especies_is_monto, NA_real_)
label(encft$p_s4b85) <- "Ingreso en especie, ocupación secundaria" 

#B.9.1. ¿Cuánto recibió en promedio el mes pasado… en dinero por sus otras ocupaciones y trabajos?
encft$p_s4b91 <- ifelse(encft$ingresos_otros_trabajos== 1, encft$ingresos_otros_trabajos_monto, NA_real_)
label(encft$p_s4b91) <- "Ganancia Ocupación terciaria, cuaternario, etc"

#==================================================
#  4: Ingresos Monetarios no laborales 
#==================================================

#----------4.1 Ingresos de capital (interes nacionales):
encft$p_s4d11_2 <- ifelse(encft$intereses_nac == 1, encft$intereses_nac_monto, NA_real_)
encft$p_s4d12_1 <- encft$intereses_nac_ano_monto/12

#Se verifica la posible duplicidad de una varibles
encft$potenciales_duplia <- ifelse(encft$p_s4d12_1 == encft$p_s4d11_2 & (!is.na(encft$p_s4d12_1) | !is.na(encft$p_s4d11_2)),1,0)
table(encft$potenciales_duplia)

#----------4.2 Pensiones:
encft$p_s4d11_1 <- ifelse(encft$pension_nac == 1, encft$pension_nac_monto, NA_real_)
encft$p_s4d11_1 <- ifelse(encft$pension_nac == 3, encft$pension_imp_monto, encft$p_s4d11_1)
encft$p_s4d12_6 <- ifelse(encft$regalia_pension_nac_ano == 1, encft$regalia_pension_nac_ano_monto/12, NA_real_)
encft$p_s4d12_6 <- ifelse(encft$pension_nac == 3, encft$regalia_pension_imp_monto/12, encft$p_s4d12_6)

#----------4.3 Alquileres:
encft$p_s4d11_3 <- ifelse(encft$alquiler_nac == 1, encft$alquiler_nac_monto, NA_real_)
encft$p_s4d12_2 <- encft$alquiler_nac_ano_monto/12

#Se verifica la posible duplicidad de una varibles
encft$potenciales_dupli1 <- ifelse(encft$p_s4d12_1 == encft$p_s4d11_2 & (!is.na(encft$p_s4d12_1) | !is.na(encft$p_s4d11_2)),1,0)
table(encft$potenciales_dupli1)

#Se verifica la posible duplicidad de una varibles
encft$potenciales_duplib <- ifelse(encft$p_s4d12_2  == encft$p_s4d11_3 & (encft$p_s4d11_3 > 0 & !is.na(encft$p_s4d11_3)),1,0)
table(encft$potenciales_duplib)

#----------4.4 Remesas nacionales:
encft$p_s4d11_4 <- ifelse(encft$remesas_nac == 1, encft$remesas_nac_monto, NA_real_)
encft$p_s4d12_3 <- encft$remesas_nac_ano_monto/12

#Se verifica la posible duplicidad de una varibles
encft$potenciales_duplic <- ifelse(encft$p_s4d12_3 == encft$p_s4d11_4 & (encft$p_s4d11_4 > 0 & !is.na(encft$p_s4d11_4)),1,0)
table(encft$potenciales_duplic)

#----------4.4Ingresos por PAE:
encft$p_s4d11_6 <-   encft$alimentos_escuela_nac_monto  							#NO SE CONSIDERA en metodología 2012 

# Ayuda empresas 
encft$p_s4d11_8 <- ifelse(encft$ayuda_empresas_nac == 1, encft$ayuda_empresas_nac_monto, NA_real_ )  #Revisar si es un ingreso ocasional 
encft$p_s4d12_4 <-  encft$ayuda_empresas_nac_ano_monto/12       				  #Revisar si es un ingreso ocasional 
  
#Se verifica la posible duplicidad de una varibles
encft$potenciales_duplid <-  ifelse(encft$p_s4d12_4 == encft$p_s4d11_8 & (encft$p_s4d11_8>0 & !is.na(encft$p_s4d11_8)),1,0)
table(encft$potenciales_duplid) 

#----------------
  encft$p_s4d11_99 <- encft$otros_ingresos_nac_monto   						
  encft$p_s4d12_99 <- encft$otros_ingresos_nac_ano_monto/12

#Se verifica la posible duplicidad de una varibles
encft$potenciales_duplie <- ifelse(encft$p_s4d12_99==encft$p_s4d11_99 & (encft$p_s4d11_99>0 & !is.na(encft$p_s4d11_99)),1,0)
table(encft$potenciales_duplie)


#S.2.6. Si usted tuviera que alquilar esta vivienda, ¿en cuánto la RD$alquilaría por mes?*/
  
encft$p_s2_6 <-  encft$monto_alquilaria_vivienda_mes
label(encft$p_s2_6) <-  "Monto mensual al que alquilaria la vivienda del hogar-Deflactado" 


#----------4.5 Ingresos en especie:
encft$p_s4d11_5 <- ifelse(encft$ayuda_especie_nac == 1, encft$ayuda_especie_nac_monto, 0)  
 encft$p_s4d12_5 <-  encft$ayuda_especie_nac_ano_monto/12 

label(encft$p_s4d11_5) <- "Ayudas en especies (mensual)"
label(encft$p_s4d12_5) <- "Ayudas en especies (año anterior)"

label(encft$p_s4d11_2) <- "Intereses o dividendos (mes anterior)"
label(encft$p_s4d11_1) <- "Pensión o jubilación (mes anterior)"
label(encft$p_s4d11_3) <- "Alquiler o renta de propiedad (mes anterior)"
label(encft$p_s4d11_4)  <- "Remesas nacionales (mes anterior)"
label(encft$p_s4d11_6) <- "Alimentos en escuela pública"
label(encft$p_s4d11_8) <- "Ayuda de empresas o institucions (mes anterior)"
label(encft$p_s4d11_99) <- "Otros ingresos nacionales nacionales (mes anterior)"

label(encft$p_s4d12_6) <- "Regalía pensión nacional (año anterior)"
label(encft$p_s4d12_1) <- "Pensión o jubilación (año anterior)"
label(encft$p_s4d12_2) <- "Alquiler o renta de propiedad (año anterior)"
label(encft$p_s4d12_3) <- "Remesas nacionales (año anterior)"
label(encft$p_s4d12_99) <- "Otros ingresos nacionales nacionales (año anterior)"
label(encft$p_s4d12_4) <- "Ayuda de empresas o instituciones (año anterior) " 

#----------4.6 Ingreso monetario no laboral por transferencias del gobierno:

encft$p_s4d11_71 =  encft$gob_comer_primero_monto
encft$p_s4d11_72 =  encft$gob_inc_asis_escolar_monto 
encft$p_s4d11_73 =  encft$gob_bono_luz_monto
encft$p_s4d11_74 =  encft$gob_bonogas_choferes_monto 
encft$p_s4d11_75 =  encft$gob_bonogas_hogares_monto 
encft$p_s4d11_76 =  encft$gob_proteccion_vejez_monto 
encft$p_s4d11_77 =  encft$gob_bono_estudiante_prog_monto 
encft$p_s4d11_78 =  encft$gob_inc_educacion_sup_monto 
encft$p_s4d11_79 =  encft$gob_inc_policia_prev_monto
encft$p_s4d11_710 =  encft$gob_inc_marina_guerra_monto
encft$p_s4d11_711 = encft$superate
encft$p_s4d11_712 = encft$quedate_en_casa 
encft$p_s4d11_713 = encft$fase 
encft$p_s4d11_714 = encft$gob_programa_pati

encft$p_s4d11_7 = rowSums(select(encft,p_s4d11_71, p_s4d11_72, p_s4d11_73, p_s4d11_74, p_s4d11_75, 
p_s4d11_76, p_s4d11_77, p_s4d11_78, p_s4d11_79, p_s4d11_710, p_s4d11_711, p_s4d11_712, p_s4d11_713, p_s4d11_714), na.rm = T)

 
label(encft$p_s4d11_71) <-  "Comer es primero"  
label(encft$p_s4d11_73) <-  "Bono Luz"  
label(encft$p_s4d11_74) <-  "Bono gas choferes"  
label(encft$p_s4d11_75) <-  "Bono gas hogares"  
label(encft$p_s4d11_76) <-  "Protección vejez"  
label(encft$p_s4d11_77) <-  "Bono a estudiante progreso"  
label(encft$p_s4d11_78) <-  "Educación superior"  
label(encft$p_s4d11_79) <-  "Policia"  
label(encft$p_s4d11_710) <-  "Marina"  
label(encft$p_s4d11_711) <-  "Superate"
label(encft$p_s4d11_72) <-  "Incentivo asistencia escolar"
label(encft$p_s4d11_7) <-   "Ayuda o transferencias del Gobierno"


# -------------------------------------------------------------------------
# Ingresos Nacionales Interno por Auto consumo
# -------------------------------------------------------------------------
  
# Investigar esta partida, daría la impresión de se más un consumo que un ingreso 

encft$p_s4d13_1 = encft$consumo_cultivo_monto*(encft$cultivo_no_remun_porc/100)

encft$p_s4d13_2 = encft$crianza_no_remun_monto*(encft$crianza_no_remun_porc/100)

encft$p_s4d13_3 = encft$pesca_no_remun_monto*(encft$pesca_no_remun_porc/100)

encft$p_s4d13_4 = encft$alimentos_no_remun_monto*(encft$alimentos_no_remun_porc/100)  

label(encft$p_s4d13_1) <-  "Autoconsumo cultivo o cosecha"
label(encft$p_s4d13_2) <-  "Autoconsumo crianza de animales,huevos, leche,etc."
label(encft$p_s4d13_3) <-  "Autoconsumo pesca"
label(encft$p_s4d13_4) <-  "Autoconsumo alimentos"	

#==================================================
#  5: Ingresos del exterior
#==================================================
  
  # se iguala a 1 las personas que reciben un ingreso del exterior y tienen missing

encft <- encft %>% 
  mutate(pension_ext_tasa = ifelse(pension_ext==1 & is.na(pension_ext_tasa),1, pension_ext_tasa),
         interes_ext_tasa = ifelse(interes_ext==1 & is.na(interes_ext_tasa),1, interes_ext_tasa),
         alquiler_ext_tasa = ifelse(alquiler_ext==1 & is.na(alquiler_ext_tasa),1,alquiler_ext_tasa),
         regalos_ext_tasa = ifelse(regalos_ext==1 & is.na(regalos_ext_tasa),1,regalos_ext_tasa),
         otros_ingresos_ext_tasa = ifelse(otros_ingresos_ext==1 & is.na(otros_ingresos_ext_tasa),1,otros_ingresos_ext_tasa))
#----------5.1 Pensiones del exterior:

encft$p_s4d21_1 <- ifelse(encft$pension_ext==1, encft$pension_ext_monto*encft$pension_ext_tasa,NA_real_)

encft %>% group_by(ano) %>%filter(edad>60) %>% summarise(mean(p_s4d21_1, na.rm = T))


#----------5.2 Intereses del exterior:
encft$p_s4d21_2 <- ifelse(encft$interes_ext==1, encft$interes_ext_monto*encft$interes_ext_tasa,NA_real_)


#----------5.3 Alquiler del exterior:

encft$p_s4d21_3 <- ifelse(encft$alquiler_ext==1, encft$alquiler_ext_monto*encft$alquiler_ext_tasa,NA_real_)



#----------5.4 Regalos del exterior:
encft$p_s4d21_4 <-  ifelse(encft$regalos_ext==1, encft$regalos_ext_monto*encft$regalos_ext_tasa,NA_real_)


# Se etiquetan las variables
label(encft$p_s4d21_1) <-  "Pensión o Jubilación-Exterior"
label(encft$p_s4d21_2) <-  "Intereses/ antes de la renta de propiedad"
label(encft$p_s4d21_3) <-  "Alquileres-Exterior"
label(encft$p_s4d21_4) <-  "Regalos no Efectivo-Exterior"

#----------5.5 Remesas del exterior:
#mes 1


for (i in 1:6) {
  var_name <- paste0("remp", i, "_1")
  
  encft <- encft %>%
    mutate(!!var_name := if_else(encft[[paste0("mes", i, "_1_ext_moneda")]] == 1, 0, NA_real_))
  
  encft <- encft %>%
    mutate(!!var_name := if_else(!is.na(encft[[paste0("mes", i, "_1_ext_monto")]]) 
        & encft[[paste0("mes", i, "_1_ext_monto")]] != 0, 
        encft[[paste0("mes", i, "_1_ext_monto")]] * encft[[paste0("mes", i, "_1_ext_tasa")]], NA_real_))
}




#mes 2

for (i in 1:6) {
  var_name <- paste0("remp", i, "_2")
  
  encft <- encft %>%
    mutate(!!var_name := if_else(encft[[paste0("mes", i, "_2_ext_moneda")]] == 1, 0, NA_real_))
  
  encft <- encft %>%
    mutate(!!var_name := if_else(!is.na(encft[[paste0("mes", i, "_2_ext_monto")]]) 
                                 & encft[[paste0("mes", i, "_2_ext_monto")]] != 0, 
                                 encft[[paste0("mes", i, "_2_ext_monto")]] * encft[[paste0("mes", i, "_2_ext_tasa")]], NA_real_))
}





#mes 3

for (i in 1:6) {
  var_name <- paste0("remp", i, "_3")
  
  encft <- encft %>%
    mutate(!!var_name := if_else(encft[[paste0("mes", i, "_3_ext_moneda")]] == 1, 0, NA_real_))
  
  encft <- encft %>%
    mutate(!!var_name := if_else(!is.na(encft[[paste0("mes", i, "_3_ext_monto")]]) 
                                 & encft[[paste0("mes", i, "_3_ext_monto")]] != 0, 
                                 encft[[paste0("mes", i, "_3_ext_monto")]] * encft[[paste0("mes", i, "_3_ext_tasa")]], NA_real_))
}




# se crea un agregado de remesas mensual 

# Calcular la suma de las variables remp1_1, remp2_1, remp3_1, remp4_1, remp5_1 y remp6_1 y asignar el resultado a p06_rem1
encft <- encft %>%
  mutate(p06_rem1 = rowSums(select(., starts_with("remp"))[, paste0("remp", 1:6, "_1")], na.rm = TRUE))

# Calcular la suma de las variables remp1_2, remp2_2, remp3_2, remp4_2, remp5_2 y remp6_2 y asignar el resultado a p06_rem2
encft <- encft %>%
  mutate(p06_rem2 = rowSums(select(., starts_with("remp"))[, paste0("remp", 1:6, "_2")], na.rm = TRUE))

# Calcular la suma de las variables remp1_3, remp2_3, remp3_3, remp4_3, remp5_3 y remp6_3 y asignar el resultado a p06_rem3
encft <- encft %>%
  mutate(p06_rem3 = rowSums(select(., starts_with("remp"))[, paste0("remp", 1:6, "_3")], na.rm = TRUE))
# se suman todos los meses 
encft$p06_rem <- rowSums(encft[, c("p06_rem1", "p06_rem2", "p06_rem3")], na.rm = TRUE)
encft$p06_rem[is.na(encft$p06_rem)] <- 0

  
encft <- encft %>%
  mutate(p_s4d22 = p06_rem / 6)



encft %>%  group_by(ano) %>% summarise(bc = sum(remesas_ext, na.rm = T),
                                       mepyd = sum(p_s4d22, na.rm = T))



#==================================================
#  6:  GENERANDO INGRESOS TOTALES NOMINALES
#==================================================
  
#----------6.1 INGRESOS LABORALES MONETARIOS Y EN ESPECIES:
  #ingresos laboral monetario
encft$In_lab_mon_op <- rowSums(select(encft,p_s4b42_1, p_s4b43_1, p_s4b43_2, p_s4b43_3,
                        p_s4b44_1,  p_s4b44_2, p_s4b44_3, p_s4b44_5, p_s4b44_6, p_s4b44_7), na.rm = T)

encft$In_lab_mon_os <-  rowSums(select(encft, p_s4b71, p_s4b72, p_s4b73), na.rm = T)

encft$In_lab_mon_in_op <-  rowSums(select(encft, p_s4b5_2a3), na.rm = T)

encft$In_lab_mon_in_os <-  rowSums(select(encft, p_4b8_2a3), na.rm = T)

#ingresos laboral en especies
encft$In_lab_esp_op <-  rowSums(select(encft, p_s4b45_1, p_s4b45_2, p_s4b45_3, 
                                       p_s4b45_4, p_s4b45_5, p_s4b45_99), na.rm = T)

encft$In_lab_esp_os <- rowSums(select(encft,p_s4b74), na.rm = T) 

encft$In_lab_esp_in_op <-  rowSums(select(encft, p_s4b55, p_s4b54), na.rm = T)

encft$In_lab_esp_in_os <- rowSums(select(encft,p_s4b84, p_s4b85), na.rm = T)

#otros ingresos laborales
encft$In_lab_otros_trab <- rowSums(select(encft,p_s4b91), na.rm = T)

#------- Grande agregados del ingreso laboral -------
encft$Ilab_mon <-  rowSums(select(encft, In_lab_mon_op, In_lab_mon_os, In_lab_mon_in_op, In_lab_mon_in_os), na.rm = T)
encft$Ilab_esp <-  rowSums(select(encft, In_lab_esp_op, In_lab_esp_os, In_lab_esp_in_op, In_lab_esp_in_os), na.rm = T)
encft$Ilab_tot <-  rowSums(select(encft, Ilab_mon, Ilab_esp, In_lab_otros_trab),na.rm = T)

label(encft$Ilab_mon) <- "Ingreso Laboral Monetario"
label(encft$Ilab_esp) <- "Ingreso Laboral Especie"
label(encft$Ilab_tot) <-  "Ingreso Laboral Total"

  encft %>% 
  group_by(ano) %>% 
  summarise(Ilab_tot = mean(Ilab_tot, na.rm = T))
  
#----------6.2 INGRESOS NACIONALES NO LABORALES:
encft$Inlab_nac_TrN_mon <- rowSums(select(encft,p_s4d11_1, p_s4d11_2, p_s4d11_3, p_s4d11_4, 
                                  p_s4d11_6, p_s4d11_7,  p_s4d12_1, p_s4d12_2, p_s4d12_3, p_s4d12_6), na.rm = T)  

encft$Inlab_nac_esp_a <-  rowSums(select(encft,p_s4d11_5, p_s4d12_5), na.rm = T)

encft$Inlab_nac_esp <-   rowSums(select(encft,Inlab_nac_esp_a), na.rm = T)

encft$Inla_trE <- rowSums(select(encft, p_s4d21_1, p_s4d21_2, p_s4d21_3, p_s4d22, p_s4d21_4), na.rm = T)

label(encft$Inlab_nac_TrN_mon) <- "Transferencias Monetarias gubernamentales"
label(encft$Inlab_nac_esp) <-  "Rentas Nacionales en especie"
label(encft$Inla_trE) <- "Transferencias del Exterior"

# Agregado total de ingresos
encft$Itotal <- rowSums(select(encft, Ilab_tot, Inlab_nac_esp, Inlab_nac_TrN_mon, Inla_trE, p_s2_6),na.rm = T)
label(encft$Itotal) <- "Ingreso del hogar-mes anterior-Deflactado"


encft %>% 
  group_by(ano) %>% 
  summarise(Itotal = mean(Itotal, na.rm = T))

#--------------6.3 Se carga la hoja de IPC, que se encuentra en la pagina web del BCRD, Se calculan los deflactores 
# se recodifica la variable MES y se crea la variable PERIODO.
ipc <- ipc_regiones_base_2019_2020 <- read_excel("ipc_regiones_base_2019-2020.xls", 
                                          range = "A6:F162")

#Llevando las variables a minúscula
names(ipc) <- tolower(names(ipc))

#Calculo de las remesas a valores del mes central del trimestre.
#Se carga la hoja de IPC, que se encuentra en la pagina web del BCRD, se recodifica la variable MES y se crea la variable PERIODO.

ipc <- ipc %>%
  drop_na(...2) %>%
  rename("ano" = "período", "mes" = "...2", "regionozama"  = "región ozama*", "regionnorte" = "región norte",
         "regioneste"  = "región este", "regionsur" = "región sur" ) %>%
  fill(ano, .direction = "down") %>%
  mutate (ano = as.double(ano),
          mes = recode(mes,
                       "Enero" = "01", "Febrero" = "02", "Marzo" = "03", "Abril" = "04", "Mayo" = "05", "Junio" = "06",
                       "Julio" = "07", "Agosto" = "08", "Septiembre" = "09", "Octubre" = "10", "Noviembre" = "11", "Diciembre" = "12"),
          periodo = as.numeric(paste(ano, mes, sep="")),
          regionozama=as.double(regionozama),
          regionnorte=as.double(regionnorte),
          regioneste=as.double(regioneste),
          regionsur = as.double(regionsur)) 

# Se crea una variable correspondiente al IPC del mes central del trimestre
ipc <- ipc %>%
  filter(periodo >= 201501)



vars <- c("regionozama", "regionnorte", "regioneste", "regionsur")

for (v in vars) {
  ipc <- ipc %>%
    mutate(!!sym(v) := !!sym(v) * 1.358727436)
}

for (v in vars) {
  ipc <- ipc %>%
    mutate(!!paste0("aux_1_ipc_central_", v) := ifelse(mes == "02" | mes == "05" | mes == "08" | mes == 11, !!sym(v), NA))
}

# Se le asigna el ipc central a los meses que son igual a missing
ipc$trimestre <- 1
ipc$trimestre <- ifelse(ipc$mes %in% c("04", "05", "06"), 2, ipc$trimestre)
ipc$trimestre <- ifelse(ipc$mes %in% c("07", "08", "09"), 3, ipc$trimestre)
ipc$trimestre <- ifelse(ipc$mes %in% c(10, 11, 12), 4, ipc$trimestre)

names <- c("regionozama", "regionnorte", "regioneste", "regionsur")





for (i in names) {
  ipc <- ipc %>%
    group_by(ano, trimestre) %>% 
    mutate(!!paste0("ipc_central_", i) := min(!!sym(paste0("aux_1_ipc_central_", i)),na.rm = T)) %>%
    ungroup()
}


# se conservan las variables basicas para actulizar las lineas 
ipc1 <- ipc %>% select(trimestre, periodo, regionozama, regionnorte, regioneste, regionsur) %>% 
  filter(periodo >= 201501) 

## se borra la variable auxiliar de trimestre



# se crea un lag y lead del ipc central, como ipc promedio
for (names in vars) {
  ipc <- ipc %>%
    mutate(!!paste0("ipc_", names, "_anterior") := lag(!!sym(names))) %>%
    mutate(!!paste0(names, "_prom") := (lag(!!sym(names), 1) + lag(!!sym(names), 2) + 
  lag(!!sym(names), 3) + lag(!!sym(names), 4) + lag(!!sym(names), 5) + lag(!!sym(names), 6)) / 6)
}




ipc <- ipc %>% 
  filter(periodo >=201507)
### Se clculan los deflactores


# Definir variables locales
names <- c("regionozama", "regionnorte", "regioneste", "regionsur")

# Calcular deflactores para cada variable
for (j in names) {
  ipc <- ipc %>% arrange(ano, trimestre, periodo)
  ipc <- ipc %>% mutate(!!paste0("deflactor_", j) := !!sym(paste0("ipc_central_", j)) / !!sym(paste0("ipc_", j, "_anterior")))
}


# Calcular deflactores moviles


ipc_prom <- NULL
ipc_central <- NULL


for (j in names) {
  ipc <- ipc %>% arrange(ano, trimestre, periodo)
  ipc <- ipc %>% mutate(!!paste0("deflactor_movil_", j) := !!sym(paste0("ipc_central_", j)) / !!sym(paste0( j, "_prom")))
}



ipc <- ipc %>% 
  select(-trimestre,-ano)


#----------7.1 Se deflactan todas las varibles de ingresos:
encft <-  left_join(encft, ipc, by = join_by(periodo)) # Se une la base de IPC con la ENCFT

## se codifica la variable macroregion 
encft <- encft %>% 
mutate(
  macro_region = case_when(
    grupo_region == "Este" ~ 4,
    grupo_region == "Gran Santo Domingo" ~ 1,
    grupo_region == "Norte o Cibao" ~ 2,
    grupo_region == "Sur" ~ 3,
    TRUE ~ NA_integer_
  )
)

encft$macro_region <- factor(encft$macro_region, labels = c("Ozama", "Norte", "Sur", "Este"))

# se deflactan las variables que se llevan al mes del centro del cada trimestre

variables <- c("p_s2_6", "p_s4b42", "p_s4b42_1", "p_s4b43_1", "p_s4b43_2", "p_s4b43_3", "p_s4b43_99", 
                "p_s4b45_1", "p_s4b45_2", "p_s4b45_3", "p_s4b45_4", "p_s4b45_5", "p_s4b45_99", 
                "p_s4b71", "p_s4b72", "p_s4b74", "p_s4b53_1", "p_s4b5_2a3", "p_s4b55", "p_s4b54", 
                "p_s4b83", "p_4b8_2a3", "p_s4b84", "p_s4b85", "p_s4b91", "p_s4d11_2", "p_s4d11_1", 
                "p_s4d11_3", "p_s4d11_4", "p_s4d11_6", "p_s4d11_8", "p_s4d11_99", "p_s4d11_5", 
                "p_s4d11_71", "p_s4d11_72", "p_s4d11_73", "p_s4d11_74", "p_s4d11_75", "p_s4d11_76", 
                "p_s4d11_77", "p_s4d11_78", "p_s4d11_79", "p_s4d11_710", "p_s4d11_711", "p_s4d11_7", 
                "p_s4d21_1", "p_s4d21_2", "p_s4d21_3", "p_s4d11_710", "p_s4d21_4", "salario_princ_imp_monto", 
                "ganancia_princ_imp_monto", "ganancia_princ_imp_monto1", "ganancia_secun_imp_monto", 
                "ganancia_secun_imp_monto1", "p_s4d13_1", "p_s4d13_2", "p_s4d13_3", "p_s4d13_4", "p_s4b73")


encft<- encft %>%
  mutate(across(contains(variables), ~ case_when(
    macro_region == 1 ~ . * deflactor_regionozama,
    macro_region == 4 ~ . * deflactor_regioneste,
    macro_region == 2 ~ . * deflactor_regionnorte,
    macro_region == 3 ~ . * deflactor_regionsur,
    TRUE ~ .
  ),  .names = "d_{.col}"))

# se deflactan las variables con el promedio móvil rezagado hasta el 6 mes anterior
variables <- c("p_s4b52", "ganancia_princ_imp_monto2", "p_s4b82", "ganancia_secun_imp_monto2", "p_s4d22")


encft<- encft %>%
  mutate(across(contains(variables), ~ case_when(
    macro_region == 1 ~ . * deflactor_movil_regionozama,
    macro_region == 4 ~ . * deflactor_movil_regioneste,
    macro_region == 2 ~ . * deflactor_movil_regionnorte,
    macro_region == 3 ~ . * deflactor_movil_regionsur,
    TRUE ~ .
  ),  .names = "d_{.col}"))




# se crean las variables con el prefijo "d_" para aquelas que no se deflactan
encft <- encft %>% 
  mutate(across(contains(c(paste0("p_s4b44_",1:7),"p_s4b44_99", "p_s4d12_1", "p_s4d12_6", "p_s4d12_2", 
                  "p_s4d12_3", "p_s4d12_99", "p_s4d12_4", "p_s4d12_5" )), ~ ., .names = "d_{.col}"))


  
# *----------7.1 GENERANDO AGREGADO DE INGRESOS DEFLACTADO.:
########################################################################################

#*INGRESOS LABORALES MONETARIOS Y EN ESPECIES
# Ingreso laboral monetario ocupación principal

# Ingresos laborales monetarios
encft$ID_lab_mon_op <- rowSums(select(encft, d_p_s4b42_1, d_p_s4b43_1, d_p_s4b43_2, d_p_s4b43_3, d_p_s4b44_1, d_p_s4b44_2, d_p_s4b44_3, d_p_s4b44_5, d_p_s4b44_6, d_p_s4b44_7), na.rm = TRUE)
encft$ID_lab_mon_os <- rowSums(select(encft, d_p_s4b71, d_p_s4b72, d_p_s4b73), na.rm = TRUE)
encft$ID_lab_mon_in_op <- rowSums(select(encft, d_p_s4b52, d_p_s4b53_1, d_ganancia_princ_imp_monto1, d_ganancia_princ_imp_monto2), na.rm = TRUE)
encft$ID_lab_mon_in_os <- rowSums(select(encft, d_p_s4b83, d_p_s4b82, d_ganancia_secun_imp_monto1, d_ganancia_secun_imp_monto2), na.rm = TRUE)

# Ingresos laborales en especie
encft$ID_lab_esp_op <- rowSums(select(encft, d_p_s4b45_1, d_p_s4b45_2, d_p_s4b45_3, d_p_s4b45_4, d_p_s4b45_5, d_p_s4b45_99), na.rm = TRUE)
encft$ID_lab_esp_os <- rowSums(select(encft, d_p_s4b74), na.rm = TRUE)
encft$ID_lab_esp_in_op <- rowSums(select(encft, d_p_s4b55, d_p_s4b54), na.rm = TRUE)
encft$ID_lab_esp_in_os <- rowSums(select(encft, d_p_s4b84, d_p_s4b85), na.rm = TRUE)

# Otros ingresos laborales
# IDng_lab_otros_trab <- rowSums(select(encft, d_p_s4b91), na.rm = TRUE)

# Agregados
encft$IDlab_mon <- rowSums(select(encft,ID_lab_mon_op, ID_lab_mon_os, ID_lab_mon_in_op, ID_lab_mon_in_os), na.rm = TRUE)
encft$IDlab_esp <- rowSums(select(encft,ID_lab_esp_op, ID_lab_esp_os, ID_lab_esp_in_op, ID_lab_esp_in_os), na.rm = TRUE)
encft$IDlab_tot <- rowSums(select(encft,IDlab_mon, IDlab_esp), na.rm = TRUE)

# Ingresos nacionales no laborales
encft$IDnlab_nac_TrN_mon <- rowSums(select(encft, d_p_s4d11_1, d_p_s4d11_2, d_p_s4d11_3, d_p_s4d11_4, 
                                           d_p_s4d11_6, d_p_s4d11_7, d_p_s4d12_1, d_p_s4d12_2, d_p_s4d12_3, d_p_s4d12_6), na.rm = TRUE)
encft$IDnlab_nac_esp_a <- rowSums(select(encft, d_p_s4d11_5, d_p_s4d12_5), na.rm = TRUE)
encft$IDnlab_nac_esp <- rowSums(select(encft, IDnlab_nac_esp_a  ), na.rm = TRUE)


# Crear variable IDnlab_nac_esp
encft <- encft %>% 
  mutate(IDnlab_nac_esp = rowSums(select(., IDnlab_nac_esp_a), na.rm = TRUE))

# Crear variable IDnla_trE
encft <- encft %>% 
  mutate(IDnla_trE = rowSums(select(., d_p_s4d21_1, d_p_s4d21_2, d_p_s4d21_3, d_p_s4d22), na.rm = TRUE))

# Etiquetar variables
label(encft$IDnlab_nac_esp) <- "Deflactado-Rentas Nacionales en especie"
label(encft$IDnlab_nac_TrN_mon) <- "Deflactado-Transferencias Nacionales Monetarias"
label(encft$IDnla_trE) <- "Deflactado-Transferencias del Exterior"

# Crear variable miembros
encft <- encft %>% 
  group_by(trimestre, periodo, vivienda, hogar) %>% 
  mutate(miembros = sum(personas)) %>% 
  ungroup()

# Crear variable d_p_s2_6m
encft <- encft %>% 
  group_by(trimestre,vivienda, hogar) %>% 
  mutate(d_p_s2_6h = sum(d_p_s2_6)) %>% 
ungroup()


encft <- encft %>% 
mutate(d_p_s2_6m = d_p_s2_6h/miembros) 
 

# Crear variables ID_total e ID_total_a
encft <- encft %>% 
  mutate(ID_total = rowSums(select(., IDlab_tot, IDnlab_nac_esp, IDnlab_nac_TrN_mon, IDnla_trE), na.rm = TRUE),
         ID_total_a = rowSums(select(., IDlab_tot, IDnlab_nac_esp, IDnlab_nac_TrN_mon, IDnla_trE, d_p_s2_6m), na.rm = TRUE))

# Etiquetar variable ID_total
label(encft$ID_total) <- "Deflactado-Ingreso del hogar-mes anterior-Deflactado"

# Eliminar variable Ihog_ENCFT y crear variable Ihog_ENCFT
encft <- encft %>% 
  group_by(trimestre, vivienda, hogar) %>% 
  mutate(Ihog_ENCFT = sum(ID_total)) %>% 
  ungroup() 

# Crear variable Ihog_ENCFT_a
encft <- encft %>% 
  mutate(Ihog_ENCFT_a = rowSums(select(., Ihog_ENCFT, d_p_s2_6), na.rm = TRUE))

# Etiquetar variable Ihog_ENCFT
label(encft$Ihog_ENCFT) <- "Ingreso del hogar-mes anterior-Deflactado"

# Crear variable IPCm_ENCFT
encft <- encft %>% 
  mutate(IPCm_ENCFT = Ihog_ENCFT_a/miembros)

# Etiquetar variable IPCm_ENCFT
label(encft$IPCm_ENCFT) <- "Ingreso percapita-mes anterior-Deflactado"


encft %>% 
  group_by(ano) %>% 
  summarise( ypc = mean(IPCm_ENCFT))

## Líneas de pobreza 
# se cargab las lineas
Lineas <- read_excel("Líneas_por_macroregion.xlsx",range = "A1:I2")

Lineas <- left_join(ipc1, Lineas , by = join_by(periodo))



regiones <- c("regionozama", "regionnorte", "regioneste", "regionsur")




for (v in regiones) {
  Lineas <- Lineas %>% 
    mutate(!!paste0("ipc_", v, "_2018") := ifelse(periodo == 201806, !!sym(v), NA),
           !!paste0("ipc_", v, "_2018_aux") := min(!!sym(paste0("ipc_", v, "_2018")), na.rm = TRUE))
}
### deflactores

ipc_2018_aux <- paste0("ipc_", names, "_2018_aux")

for (j in names) {
  Lineas <- Lineas %>%
    mutate(!!paste0("deflac_base_2007_", j) := !!sym(j) / !!sym(paste0("ipc_", j, "_2018_aux")))
}

#***** Se crean variables con el valor de las líneas de junio 2007
 
var_list <- c( "general_regionozama", "general_regionnorte", "general_regioneste", "general_regionsur",  
               "extrema_regionozama", "extrema_regionnorte", "extrema_regioneste", "extrema_regionsur" )
 
 # Iterar sobre las variables en var_list
 for (j in var_list) {
   # Crear la variable j_aux y asignarle el valor mínimo de la variable j
   Lineas <- Lineas %>%
     mutate(!!paste0(j, "_aux") := min(!!sym(j), na.rm = TRUE))
 }
 
#*Se indexan las lineas con el deflacor creado base junio 2018 general 
 
names <- c("regionozama", "regionnorte", "regioneste", "regionsur")
linea_general <- paste0("general_", names, "_aux")
deflactores <- paste0("deflac_base_2007_", names)
 
 

 # Definir los periodos de interés
 periodos_1 <- c(201602, 201605, 201608, 201611, 201702, 201705, 201708, 201711)
 periodos_2 <- c(201802, 201805, 201808, 201811, 201902, 201905, 201908, 201911)
 periodos_3 <- c(202002, 202005, 202008, 202011, 202102, 202105, 202108, 202111, 202202, 202205, 202208, 202211)
 
 # Iterar sobre las variables en var_list
 for (i in names) {
   Lineas <- Lineas %>%
     mutate(!!paste0("linea_general_", i) := !!sym(paste0("general_", i, "_aux")) * !!sym(paste0("deflac_base_2007_", i))) %>%
     mutate(!!paste0("linea_general_", i) := case_when(periodo %in% periodos_1 ~ !!as.name(paste0("linea_general_", i)),
                                                       periodo %in% periodos_2 ~ !!as.name(paste0("linea_general_", i)),
                                                       periodo %in% periodos_3 ~ !!as.name(paste0("linea_general_", i)),
                                                       TRUE ~ NA))
 }
 ## lineas extrema 
 
 linea_extrema <- paste0("extrema_", names, "_aux")
 deflactores <- paste0("deflac_base_2007_", names)
 
 
 
 # Definir los periodos de interés
 periodos_1 <- c(201602, 201605, 201608, 201611, 201702, 201705, 201708, 201711)
 periodos_2 <- c(201802, 201805, 201808, 201811, 201902, 201905, 201908, 201911)
 periodos_3 <- c(202002, 202005, 202008, 202011, 202102, 202105, 202108, 202111, 202202, 202205, 202208, 202211)
 
 # Iterar sobre las variables en var_list
 for (i in names) {
   Lineas <- Lineas %>%
     mutate(!!paste0("linea_extrema_", i) := !!sym(paste0("extrema_", i, "_aux")) * !!sym(paste0("deflac_base_2007_", i))) %>%
     mutate(!!paste0("linea_extrema_", i) := case_when(periodo %in% periodos_1 ~ !!as.name(paste0("linea_extrema_", i)),
                                                       periodo %in% periodos_2 ~ !!as.name(paste0("linea_extrema_", i)),
                                                       periodo %in% periodos_3 ~ !!as.name(paste0("linea_extrema_", i)),
                                                       TRUE ~ NA))
 }
 # se establecen las lineas para todos los periodos 


 
 # Filtrar los datos para mantener solo los periodos desde 201601 en adelante
 Lineas <- Lineas %>%
   filter(periodo >= 201601)
 
 var_list <- c("linea_urbanogeneral_aux", "linea_urbanoextrema_aux", "linea_ruralgeneral_aux", "linea_ruralextrema_aux")
 
 # Ordenar los datos por periodo
 Lineas <- Lineas %>%
   arrange(periodo) 


 # Restaurar el orden original
 Lineas <- Lineas %>%
   arrange(periodo) %>% 
   select(periodo, linea_urbanogeneral_aux, linea_urbanoextrema_aux, linea_ruralgeneral_aux, linea_ruralextrema_aux)
 
 columnas <- c("linea_general_regionozama", "linea_general_regionnorte", "linea_general_regioneste", "linea_general_regionsur",
               "linea_extrema_regionozama", "linea_extrema_regionnorte", "linea_extrema_regioneste", "linea_extrema_regionsur")

 
 
 
 
 #Renombramos las variables 
 
 columns <- c("periodo", "linea_general_regionozama", "linea_general_regionnorte", "linea_general_regioneste", "linea_general_regionsur",
              "linea_extrema_regionozama", "linea_extrema_regionnorte", "linea_extrema_regioneste", "linea_extrema_regionsur")
 
 Lineas <- Lineas[, columns]
 Lineas <- Lineas %>% mutate(across(everything(), ~as.numeric(.), .names = "{.col}"))  # Convertir todas las columnas a numéricas
 Lineas <- Lineas %>% mutate(across(everything(), ~round(., 2), .names = "{.col}"))  # Formatear todas las columnas a 9.2f
 
 
 ### se llevan las lineas a la ENCFT
 
 encft <- left_join(encft, Lineas, by = join_by(periodo))
 
 ## Recodificamos la variable zona y calculamos pobreza
 encft <- encft %>% 
 mutate(linea_pob = case_when(macro_region == "Ozama" ~ linea_general_regionozama,
                              macro_region == "Este" ~ linea_general_regioneste,
                              macro_region == "Sur" ~ linea_general_regionsur,
                              macro_region == "Norte" ~ linea_general_regionnorte,
                              TRUE ~ NA_real_),
        linea_ind = case_when(macro_region == "Ozama" ~ linea_extrema_regionozama,
                              macro_region == "Este" ~ linea_extrema_regioneste,
                              macro_region == "Sur" ~ linea_extrema_regionsur,
                              macro_region == "Norte" ~ linea_extrema_regionnorte,
                              TRUE ~ NA_real_))
   ## Se calcula pobreza
 
 encft <- encft %>%
   arrange(trimestre, periodo) %>% 
   mutate(pobre = IPCm_ENCFT < linea_pob,
          indigente = IPCm_ENCFT < linea_ind,
          FGT_pobreza = pobre * 100,
          FGT_indigencia = indigente * 100)
 
 
 #### Se hace una summ de la variable FGT_pobreza por año
 
 encft %>% 
   group_by(ano) %>% 
   summarise(FGT_pobreza = round(weighted.mean(FGT_pobreza, factor_expansion/4, na.rm = T),digits=4))

 #### SA partir de aquí puede desagregar el indicador de pobreza según sus necesidades. 
 ### Tome en cuenta que la ENCFT es una encuesta  por muestreo complejo. 
 ### Debe verificar la representatividad de dichas de dichas desagregaciones.